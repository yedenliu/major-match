'''
Created by Eden Liu (yl9) and Mingyan Claire Tian (mt1) for CS304 Spring 2022
CS304 Spring 2022
H7: Crud Assigment
'''

import cs304dbi as dbi

def insert_movie(conn, tt, title, release):
    '''
    Inserts title give user's input of tt, title, release into
    Eden's uid: 8368
    '''
    curs = dbi.cursor(conn)
    addedby = 8368
    # prepared query
    sql = '''   insert into movie(tt, title, `release`, addedby)
                values (%s, %s, %s, %s)
            '''
    curs.execute(sql, [tt, title, release, addedby])
    conn.commit()
    
def check_movie(conn, tt):
    '''
    Checks if movie already exists in database
    Return true if movie already exists
    '''
    curs = dbi.cursor(conn)
    sql = ''' select * from movie where tt = %s '''
    curs.execute(sql, [tt])
    movie = curs.fetchall()
    return len(movie) > 0

def get_title(conn, tt):
    '''
    Gets title of a movie given the tt
    Param - connection object, title id (tt)
    Return - title of movie (string)
    '''
    curs = dbi.cursor(conn)
    # prepared query
    sql = 'select title from movie where (tt = %s)'
    curs.execute(sql, [tt])
    row = curs.fetchone()
    if not row: 
        return 'None'
    else:
        return row[0]

def get_addedby(conn, tt):
    '''
    Gets the name of the use that added the person given the person's id
    Param - connection object, person id (nm)
    Return - name of added by user (string), NULL if none
    '''
    curs = dbi.cursor(conn)
    # prepared query
    sql = '''select addedby 
             from movie 
             where tt = %s'''
    curs.execute(sql, [tt])
    row = curs.fetchone()
    if not row: #this is to deal with NULL users
        return 'None'
    else:
        return row[0]

def get_release(conn, tt):
    '''
    Gets the release date of a movie given the tt
    Param - connection object, title id (tt)
    Return - year of release (string)
    '''
    curs = dbi.cursor(conn)
    # prepared query
    sql = 'select `release` from movie where (tt = %s)'
    curs.execute(sql, [tt])
    row = curs.fetchone()
    if not row:
        return 'None'
    else:
        return row[0]

def get_dir_id(conn, tt):
    '''
    Gets the director id of a movie given the tt
    Param - connection object, title id (tt)
    Return - director id
    '''
    curs = dbi.cursor(conn)
    # prepared query
    sql = 'select director from movie where (tt = %s)'
    curs.execute(sql, [tt])
    row = curs.fetchone()
    if not row:
        return 'None'
    else:
        return row[0]
    

def get_dir_name(conn, tt):
    '''
    Gets the director name of a movie given the tt
    Param - connection object, title id (tt)
    Return - director name (string)
    '''
    curs = dbi.cursor(conn)
    nm = get_dir_id(conn,tt)
    # prepared query
    sql = 'select `name` from person where (nm = %s)'
    curs.execute(sql, [nm])
    row = curs.fetchone()
    if not row:
        return 'None'
    else:
        return row[0]

def update_movie(conn, title, release, addedby, dir_id, tt):
    '''
    Given movie id, update the fields of a movie
    '''
    curs = dbi.cursor(conn)
    # prepared query
    sql = '''   update movie
                set %s, %s, %s, %s
                where tt = %(tt)s
            '''
    curs.execute(sql, [title, release, dir_id, addedby, tt])
    conn.commit()

def delete_movie(conn, tt):
    '''
    Delete a movie from the movie table
    '''
    curs = dbi.cursor(conn)
    # prepared query
    sql = '''   delete from movie
                where tt = %s
            '''
    curs.execute(sql, [tt])
    conn.commit()