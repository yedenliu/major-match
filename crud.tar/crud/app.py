'''
Created by Eden Liu (yl9) and Mingyan Claire Tian (mt1) for CS304 Spring 2022
Using Scott's starter pack
CS304 Spring 2022
H7: Crud Assigment
'''
from flask import (Flask, render_template, make_response, url_for, request,
                   redirect, flash, session, send_from_directory, jsonify)
from werkzeug.utils import secure_filename
app = Flask(__name__)

import cs304dbi as dbi
import random
from prepared_queries import *

################################################################################
app.secret_key = 'your secret here'
# replace that with a random key
app.secret_key = ''.join([ random.choice(('ABCDEFGHIJKLMNOPQRSTUVXYZ' +
                                          'abcdefghijklmnopqrstuvxyz' +
                                          '0123456789'))
                           for i in range(20) ])

# This gets us better error messages for certain common request errors
app.config['TRAP_BAD_REQUEST_ERRORS'] = True
################################################################################

@app.route('/')
def index():
    return render_template('index.html',page_title='Mainpage')

@app.route('/insert/', methods=['GET','POST'])
def insert():
    if request.method == 'GET':
        return render_template('insert.html',page_title='Insert A Movie')
    else:
        tt = request.form.get('movie-tt')
        title = request.form.get('movie-title')
        release = request.form.get('movie-release')
        if len(tt) == 0 or len(title) == 0 or len(release) == 0:
            flash('Missing field(s)')
        if not (check_movie(conn, tt)): # if movie doesn't exist
            insert_movie(conn, tt, title, release)
            return redirect(url_for('update'), tt=tt)
        flash('Movie already exists')
        return render_template('insert.html',page_title='Insert A Movie')

@app.route('/search/')
def search():
    return render_template('search.html',page_title='Search Movies')

@app.route('/select/')
def select():
    return render_template('select.html',page_title='Select Incomplete Movies')

@app.route('/update/<tt>')
def update(tt):
    if request.method == 'GET':
        title = get_title(conn, tt)
        release = get_release(conn, tt)
        addedby = get_addedby(conn, tt)
        dir_id = get_dir_id(conn, tt)
        dir_name = get_dir_name(conn, tt)
        return render_template('update.html',
                                page_title='Update Movie:' + title,
                                title = title,
                                tt = tt,
                                release = release,
                                addedby = addedby,
                                dir_id = dir_id,
                                dir_name = dir_name)
    else:
        if request.values('update'):
            title = request.form.get('movie-title')
            release = request.form.get('movie-release')
            addedby = request.form.get('movie-addedby')
            dir_id = request.form.get('movie-director')
            update_movie(conn, title, release, addedby, dir_id, tt)
            dir_name = get_dir_name(conn, tt)
            return render_template('update.html',
                                page_title='Update Movie:' + title,
                                title = title,
                                tt = tt,
                                release = release,
                                addedby = addedby,
                                dir_id = dir_id,
                                dir_name = dir_name)
        elif request.values('delete'):
            delete_movie(conn, tt)
            flash("Movie successfully deleted!")
            return redirect(url_for('index'))

################################################################################
@app.before_first_request
def init_db():
    dbi.cache_cnf()
    # set this local variable to 'wmdb' or your personal or team db
    db_to_use = 'yl9_db' 
    dbi.use(db_to_use)
    print('will connect to {}'.format(db_to_use))

if __name__ == '__main__':
    import sys, os
    if len(sys.argv) > 1:
        # arg, if any, is the desired port number
        port = int(sys.argv[1])
        assert(port>1024)
    else:
        port = os.getuid()
        conn = dbi.connect()
    app.debug = True
    app.run('0.0.0.0',port)
